import React from "react";
import './Dashboard.css'



function Profile(){
    return(
        <>
        <div className="container">
        <h1>this is Profile</h1>
        </div>
        </>
    );
}

export default Profile;