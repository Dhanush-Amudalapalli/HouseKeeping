import React from "react";
import './Dashboard.css';



function Dashboard(){
   
    return(
        <><div className="container">
         <div class="flex-container">
  <div>Requests</div>
  <div>suggestions</div>
  <div>Feedback</div>  
</div>
</div>
        
        </>
    );
}

export default Dashboard;