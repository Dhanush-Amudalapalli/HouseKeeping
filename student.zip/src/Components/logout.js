import React from "react";
import './Dashboard.css';



function Logout(){
    return(
        <><div className="container">
        <h1>this is Logout Page</h1>
        </div>
        </>
    );
}

export default Logout;