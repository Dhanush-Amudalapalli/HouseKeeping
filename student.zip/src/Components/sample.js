import React from "react";

    function Sample(props) {
        
    
    return(
        <div></div>
//       <div align="center">
// <div style={{
//           border: '2px solid blue',
//           padding: '1px',
//           margin: '2px',
//           backgroundColor:"#86de7a",
//           borderRadius: '10px',
//           width: '500px',
//         }}>
//         <h4 align="center">
//           {props.productObj.id} - {props.productObj.name}
//         </h4>
//         <span style={{ textAlign: 'center' }}> Product Category: {props.productObj.category} </span>   <br />
        
//       </div>
//       </div>
    );
    }
export default Sample;